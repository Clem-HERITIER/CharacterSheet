﻿namespace Wfrp.Domain.Entities
{
    public enum StatusTier
    {
        Bronze,
        Silver,
        Gold
    }
}
